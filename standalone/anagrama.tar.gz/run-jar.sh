java -jar dist/anagrama.jar anagrama.txt
